// dom
// - Dùng JS để truy xuất vào các thẻ của html
// fetch
// - Fetch dùng để gửi request tới API lấy dữ liệu về (ở bài của mình là file db.json)
// forEach
// - Vòng lặp dùng để lấy các phần tử trong mảng
// filter
// - filter dùng để loại bỏ phần tử theo điều kiện

// Mảng này dùng để lưu dữ liệu lấy từ fetch
let products = [];

// Khai báo 1 hàm để lấy dữ liệu
function layDuLieu() {
  // Sử dụng fetch để lấy dữ liệu từ file db.json
  // Cú pháp: fetch('link api' hoặc 'file db.json')
  // response.json(): lấy dữ liệu từ file db.json
  fetch("./db.json")
    .then((response) => response.json())
    .then((data) => {
      // Gán lại giá trị cho mảng products là dữ liệu trong file db.json
      products = data.products1;
    });
}
layDuLieu();
console.log(products);
